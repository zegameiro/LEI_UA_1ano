﻿var formvalid = {
    firstname: false,
    lastname: false,
    email: false
};

function validate() {
    if (formvalid.firstname && formvalid.lastname && formvalid.email) {
        $('#subbutton').removeAttr('disabled');
    } else {
        $('#subbutton').attr('disabled', true);
    }
};

$('#firstName').on('input', function () {
    var firstname = $(this).val();
    if (firstname.length < 1) {
        $('#firstNameERROR').show();
        formvalid.firstname = false;
        validate();
    } else {
        $('#firstNameERROR').hide();
        formvalid.firstname = true;
        validate();
        var testExp = new RegExp(/^[a-zA-Z\u00C0-\u017F]+$/);
        if (!testExp.test(firstname)) {
            $('#firstNameERROR').show();
            formvalid.firstname = false;
            validate();
        } else {
            $('#firstNameERROR').hide();
            formvalid.firstname = true;
            validate()
            if (firstname.length < 3) {
                $('#firstNameERROR').show();
                formvalid.firstname = false
                validate();
            } else {
                $('#firstNameERROR').hide();
                formvalid.firstname = true;
                validate();
            }
        }
    }
});

$('#lastName').on('input', function () {
    var lastname = $(this).val();
    if (lastname.length < 1) {
        $('#lastNameERROR').show();
        formvalid.lastname = false;
        validate();
    } else {
        $('#lastNameERROR').hide();
        formvalid.lastname = true;
        validate();
        var testExp = new RegExp(/^[a-zA-Z\u00C0-\u017F]+$/);
        if (!testExp.test(lastname)) {
            $('#lastNameERROR').show();
            formvalid.lastname = false;
            validate();
        } else {
            $('#lastNameERROR').hide();
            formvalid.lastname = true;
            validate();
            if (lastname.length < 3) {
                $('#lastNameERROR').show();
                formvalid.lastname = false;
                validate();
            } else {
                $('#lastNameERROR').hide();
                formvalid.lastname = true;
                validate();
            }
        }
    }
});

$('#email').on('input', function () {
    var email = $(this).val();
    if (email.length < 1) {
        $('#emailERROR').show();
        formvalid.email = false;
        validate();
    } else {
        $('#emailERROR').hide();
        formvalid.email = true;
        validate();
        var testExp = new RegExp(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/);
        if ( !testExp.test(email)) {
            $('#emailERROR').show();
            formvalid.email = false;
            validate();
        } else {
            $('#emailERROR').hide();
            formvalid.email = true;
            validate()
            if (email.length < 3) {
                $('#emailERROR').show();
                formvalid.email = false
                validate();
            } else {
                $('#emailERROR').hide();
                formvalid.email = true;
                validate();
            }
        }
    }
});