﻿// ViewModel KnockOut
var vm = function () {

    console.log('ViewModel initiated...');
    //---Variáveis locais
    var self = this;
    var allRecords = [];
    self.search = ko.observable('');
    self.baseUri = ko.observable('http://192.168.160.58/Formula1/api/constructors');
    self.displayName = 'Constructors List';
    self.error = ko.observable('');
    self.passingMessage = ko.observable('');
    self.records = ko.observableArray([]);
    self.currentPage = ko.observable(1);
    self.pagesize = ko.observable(20);
    self.totalRecords = ko.observable(50);
    self.hasPrevious = ko.observable(false);
    self.hasNext = ko.observable(false);
    self.previousPage = ko.computed(function () {
        return self.currentPage() * 1 - 1;
    }, self);
    self.nextPage = ko.computed(function () {
        return self.currentPage() * 1 + 1;
    }, self);
    self.fromRecord = ko.computed(function () {
        return self.previousPage() * self.pagesize() + 1;
    }, self);
    self.toRecord = ko.computed(function () {
        return Math.min(self.currentPage() * self.pagesize(), self.totalRecords());
    }, self);
    self.totalPages = ko.observable(0);

    self.pageArray = function () {
        var list = [];
        var size = Math.min(self.totalPages(), 9);
        var step;
        if (size < 9 || self.currentPage() === 1)
            step = 0;
        else if (self.currentPage() >= self.totalPages() - 4)
            step = self.totalPages() - 9;
        else
            step = Math.max(self.currentPage() - 5, 0);

        for (var i = 1; i <= size; i++)
            list.push(i + step);
        return list;
    };

    //--- Page Events
    self.activate = function (id) {
        console.log('CALL: getConstructors...');
        ajaxHelper(self.baseUri(), 'GET').done(function (data) {
            allRecords = data.List;
        });
        var composedUri = self.baseUri() + "?page=" + id + "&pageSize=" + self.pagesize();
        ajaxHelper(composedUri, 'GET').done(function (data) {
            console.log("lkfdjs", composedUri)
            console.log(data);
            hideLoading();
            self.records(data.List);
            self.currentPage(data.CurrentPage);
            self.hasNext(data.HasNext);
            self.hasPrevious(data.HasPrevious);
            self.pagesize(data.PageSize)
            self.totalPages(data.PageCount);
            self.totalRecords(data.Total);
        });

    };

    self.activateSearch = function (pg) {
        console.log('CALL: getConstructors for search...');
        ajaxHelper(self.baseUri(), 'GET').done(function (data) {
            allRecords = data.List;

            let filteredRecords = allRecords.filter((r) => {
                let s = r.ConstructorId + " " + r.Name + " " + r.Nationality;
                s = s.toLowerCase();

                return s.includes(self.search());
            })

            let currPage = parseInt(pg);
            let totalPages = Math.ceil(filteredRecords.length / self.pagesize());
            let initRecord = self.pagesize() * (currPage - 1);
            let finalRecord = initRecord + self.pagesize();

            console.log(currPage, totalPages, initRecord, finalRecord)

            self.records(filteredRecords.slice(initRecord, finalRecord));
            hideLoading();
            self.currentPage(currPage);
            self.hasNext(currPage < totalPages);
            self.hasPrevious(currPage > 1);
            self.totalPages(totalPages);
        });
    };

    //--- Internal functions
    function ajaxHelper(uri, method, data) {
        self.error(''); // Clear error message
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("AJAX Call[" + uri + "] Fail...");
                hideLoading();
                self.error(errorThrown);
            }
        });
    }

    $('th').on('click', function () {
        console.log('bacalhau');
        var column = $(this).data('column')
        var order = $(this).data('order')
        var text = $(this).html()
        text = text.substring(0, text.length - 1)

        if (order == "desc") {
            $(this).data('order', "asc")
            self.records = self.records.sort((a, b) => a[column] > b[column] ? 1 :
                -1)
            text += '&#9660'
        } else {
            $(this).data('order', "desc")
            self.records = self.records.sort((a, b) => a[column] < b[column] ? 1 :
                -1)
            text += '&#9650'
        }
        $(this).html(text)
    })

    function sleep(milliseconds) {
           const start = Date.now();
           while (Date.now() - start < milliseconds);
    }

    $('#search-input').on('keyup', function () {
        var value = $(this).val().toLowerCase();

        self.search(value);

        let filteredRecords = allRecords.filter((r) => {
            let s = r.ConstructorId + " " + r.Name + " " + r.Nationality;
            s = s.toLowerCase();

            return s.includes(value);
        })

        self.records(
            filteredRecords.slice(0, self.pagesize())
        )

        self.currentPage(1);
        self.hasNext(true);
        self.hasPrevious(false);
        self.totalPages(Math.ceil(filteredRecords.length / self.pagesize()));
    })

    function showLoading() {
        $("#myModal").modal('show', {
            keyboard: false
        });
    }
    function hideLoading() {
        $('#myModal').on('shown.bs.modal', function (e) {
            $("#myModal").modal('hide');
        })
    }

    function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        console.log("sPageURL=", sPageURL);
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);

            }
        }
    };

    //--- start ....
    showLoading();
    var pg = getUrlParameter('page');
    var search = getUrlParameter('search');
    console.log(search);
    console.log(pg);
    self.search(search);
    $("#search-input").val(search);

    if (search == undefined) {
        if (pg == undefined)
            self.activate(1);
        else {
            self.activate(pg);
        }
    } else {
        console.log("por fazer")
        self.activateSearch(pg);
    }

};

$(document).ready(function () {
    console.log("ready! go");
    ko.applyBindings(new vm());

});