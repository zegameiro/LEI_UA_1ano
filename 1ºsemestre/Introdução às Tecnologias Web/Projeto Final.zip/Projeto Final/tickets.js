﻿var amount = 0;
var price = 0;
var control = 0;

function buy(number) {
    val = document.getElementById('ticketprice' + number).value;
    price += parseFloat(val);
    console.log(price)
    amount++;
    calculate();
}

function calculate() {
    if (amount > 4) {
        var discountprice = price - (price * 0.3);
        control = 1;
    }
    document.getElementById('amounts').innerText = amount;
    if (control == 1) {
        document.getElementById('total').innerText = discountprice.toFixed(2);
    } else {
        document.getElementById('total').innerText = price.toFixed(2);
    }
}

function validate() {
    if (amount == 0) {
        alert("Buy at let one ticket")
        return false
    } else {
        return true;
    }
}


function reset() {
    document.getElementById('total').innerText = "0.00";
    document.getElementById('amounts').innerText = "0";
    amount = 0;
    price = 0;
    /*control = 0;*/
};

$(function () {
    // An array of dates
    var eventDates = {};
    eventDates[new Date('03/20/2022')] = new Date('03/20/2022');
    eventDates[new Date('03/27/2022')] = new Date('03/27/2022');
    eventDates[new Date('04/10/2022')] = new Date('04/10/2022');
    eventDates[new Date('04/24/2022')] = new Date('04/24/2022');
    eventDates[new Date('05/08/2022')] = new Date('05/08/2022');
    eventDates[new Date('05/22/2022')] = new Date('05/22/2022');
    eventDates[new Date('05/29/2022')] = new Date('05/29/2022');
    eventDates[new Date('06/12/2022')] = new Date('06/12/2022');
    eventDates[new Date('06/19/2022')] = new Date('06/19/2022');
    eventDates[new Date('07/03/2022')] = new Date('07/03/2022');
    eventDates[new Date('07/10/2022')] = new Date('07/10/2022');
    eventDates[new Date('07/24/2022')] = new Date('07/24/2022');
    eventDates[new Date('07/31/2022')] = new Date('07/31/2022');
    eventDates[new Date('08/28/2022')] = new Date('08/28/2022');
    eventDates[new Date('09/04/2022')] = new Date('09/04/2022');
    eventDates[new Date('09/11/2022')] = new Date('09/11/2022');
    eventDates[new Date('09/25/2022')] = new Date('09/25/2022');
    eventDates[new Date('10/02/2022')] = new Date('10/02/2022');
    eventDates[new Date('10/09/2022')] = new Date('10/09/2022');
    eventDates[new Date('10/23/2022')] = new Date('10/23/2022');
    eventDates[new Date('10/30/2022')] = new Date('10/30/2022');
    eventDates[new Date('11/13/2022')] = new Date('11/13/2022');
    eventDates[new Date('11/20/2022')] = new Date('11/20/2022');
    // datepicker
    $('#datepicker').datepicker({
        beforeShowDay: function (date) {
            var highlight = eventDates[date];
            if (highlight) {
                return [true, "event", 'Tooltip text'];
            } else {
                return [true, '', ''];
            }
        }
    });
});